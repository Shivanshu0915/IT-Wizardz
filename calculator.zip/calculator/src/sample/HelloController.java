package sample;
import java.util.*;
//import java.lang.*;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.event.ActionEvent;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    public TextField T2,T3;
    public Label q1,q2;
    double d1,d2;
    char c1;
    @FXML
    public void click0() {T2.setText(T2.getText() + "0");}
    public void click1() {T2.setText(T2.getText() + "1");}
    public void click2() {T2.setText(T2.getText() + "2");}
    public void click3() {T2.setText(T2.getText() + "3");}
    public void click4() {T2.setText(T2.getText() + "4");}
    public void click5() {T2.setText(T2.getText() + "5");}
    public void click6() {T2.setText(T2.getText() + "6");}
    public void click7() {T2.setText(T2.getText() + "7");}
    public void click8() {T2.setText(T2.getText() + "8");}
    public void click9() {T2.setText(T2.getText() + "9");}
    public void dot() {T2.setText(T2.getText() + ".");}

    public void mclick0() {T3.setText(T3.getText() + "0");}
    public void mclick1() {T3.setText(T3.getText() + "1");}
    public void mclick2() {T3.setText(T3.getText() + "2");}
    public void mclick3() {T3.setText(T3.getText() + "3");}
    public void mclick4() {T3.setText(T3.getText() + "4");}
    public void mclick5() {T3.setText(T3.getText() + "5");}
    public void mclick6() {T3.setText(T3.getText() + "6");}
    public void mclick7() {T3.setText(T3.getText() + "7");}
    public void mclick8() {T3.setText(T3.getText() + "8");}
    public void mclick9() {T3.setText(T3.getText() + "9");}
    public void mdot() {T3.setText(T3.getText() + ".");}

    String checkstr = "";
    //----------------------- Basic functions like add,sub, main win -------------------------------------------------------
    public void add(){
        String h=(T2.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T2.getText());
        c1='+';T2.setText(T2.getText() + "+");
    }
    public void sub(){
        String h=(T2.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T2.getText());
        c1='-';T2.setText(T2.getText() + "-");
    }
    public void mul(){
        String h=(T2.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T2.getText());
        c1='*';T2.setText(T2.getText() + "*");
    }
    public void div(){
        String h=(T2.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T2.getText());
        c1='/';T2.setText(T2.getText() + "/");
    }
    public void del() {
        try {
            String s = T2.getText();
            T2.setText(s.substring(0, s.length() - 1));
        }catch(Exception e){
        }
    }
    public void clean(){
        T2.setText("");q1.setText("");
    }
    public void percent(){
        try {
            double a = Double.parseDouble(T2.getText());
            double b = a / 100;
            q1.setText("percent(" + T2.getText() + ")" + " =");
            T2.setText("" + b);
        }catch (Exception e){
        }
    }
    public void fsqrt(){
        try {
            double a = Double.parseDouble(T2.getText());
            double b = Math.sqrt(a);
            q1.setText("√" + a + " =");
            T2.setText("" + b);
        }catch (Exception e){
        }
    }
    public void fnegate(){
        try {
            double a = Double.parseDouble(T2.getText());
            double b = -a;
            T2.setText("" + b);
        }catch (Exception e){
        }
    }
    public void fxx(){
        try {
            double a = Double.parseDouble(T2.getText());
            double b = a * a;
            T2.setText("" + b);
        }catch (Exception e){
        }
    }
    public void fFact(){
        try {
            int i, f = 1;
            int a = Integer.parseInt(T2.getText());
            for (i = 1; i <= a; i++) {
                f = f * i;
            }
            q1.setText(a + "! =");
            T2.setText("" + f);
        }catch (Exception e){
        }
    }

    public void equal(){
        String s1=T2.getText(),s2;
        double d3;
        switch(c1)
        {
            case '+':
                s2=s1.substring(s1.indexOf('+')+1);
                d2=Double.parseDouble(s2);
                d3=d1+d2;
                q1.setText(T2.getText()+"=");
                T2.setText(""+d3);
                break;
            case '-':
                s2=s1.substring(s1.indexOf('-')+1);
                d2=Double.parseDouble(s2);
                d3=d1-d2;
                q1.setText(T2.getText()+"=");
                T2.setText(""+d3);
                break;
            case '*':
                s2=s1.substring(s1.indexOf('*')+1);
                d2=Double.parseDouble(s2);
                d3=d1*d2;
                q1.setText(T2.getText()+"=");
                T2.setText(""+d3);
                break;
            case '/':
                s2=s1.substring(s1.indexOf('/')+1);
                d2=Double.parseDouble(s2);
                d3=d1/d2;
                q1.setText(T2.getText()+"=");
                T2.setText(""+d3);
                break;
        }
    }
    double mx;
//----------------------------- Maths function -------------------------------------------------------------------------
    public void sin(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.sin(a);
            q2.setText("sin(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch (Exception e){}
    }
    public void tan(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.tan(a);
            q2.setText("tan(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch (Exception e){}
    }
    public void cos(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.cos(a);
            q2.setText("cos(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch (Exception e){}
    }
    public void sec(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = 1 / Math.cos(a);
            q2.setText("sec(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch (Exception e){}
    }
    public void cosec(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = 1 / Math.sin(a);
            q2.setText("cosec(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void cot(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = 1 / Math.tan(a);
            q2.setText("cot(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch (Exception e){}
    }
    public void degToRad(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.toRadians(a);
            q2.setText(a + "deg to rad=");
            T3.setText("" + b);
        }catch (Exception e){}
    }
    public void radToDeg(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.toDegrees(a);
            q2.setText(a + "rad to deg=");
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void exp(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.exp(a);
            q2.setText("exp" + a + " =");
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void invx(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = 1 / a;
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void log(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.log10(a);
            q2.setText("log(" + a + ") =");
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void ln(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.log(a);
            q2.setText("ln(" + a + ") =");
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void sqrt(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.sqrt(a);
            q2.setText("√" + a + " =");
            T3.setText("" + b);
        }catch (Exception e){}
    }
    public void fact(){
        try {
            int i, f = 1;
            int a = Integer.parseInt(T3.getText());
            for (i = 1; i <= a; i++) {
                f = f * i;
            }
            q2.setText(a + "! =");
            T3.setText("" + f);
        }catch(Exception e){}
    }
    public void mod(){
        try {
            double a = Double.parseDouble(T3.getText());
            if (a < 0) {
                double b = -a;
                T3.setText("" + b);
            } else {
                T3.setText("" + a);
            }
        }catch (Exception e){}
    }
    public void arcsin(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.asin(a);
            q2.setText("arc sin(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch (Exception e){}
    }
    public void arccos(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.acos(a);
            q2.setText("arc cos(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void arctan(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.atan(a);
            q2.setText("arc tan(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void arccosec(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = 1 / Math.asin(a);
            q2.setText("arc cosec(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch (Exception e){}
    }
    public void arcsec(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = 1 / Math.acos(a);
            q2.setText("arc sec(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void arccot(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.atan(a);
            q2.setText("arc cot(" + T3.getText() + ")" + " =");
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void negate(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = -a;
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void xx(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = a * a;
            T3.setText("" + b);
        }catch(Exception e){}
    }
    public void xToY(){
        try {
            mx = Double.parseDouble(T3.getText());
            q2.setText(T3.getText() + "^");
            T3.setText("");
            c1 = 'X';
        }catch (Exception e){}
    }
    public void tenToX(){
        try {
            double a = Double.parseDouble(T3.getText());
            double b = Math.pow(10, a);
            q2.setText("10^" + a + " =");
            T3.setText("" + b);
        }catch (Exception e) {
        }
    }
    public void mback(ActionEvent event){
        Pane4.setVisible(false);
        ((Stage)(((Button)event.getSource()).getScene().getWindow())).setWidth(445);
        ((Stage)(((Button)event.getSource()).getScene().getWindow())).setHeight(612);
        Pane2.setVisible(true);
    }


//------------------------------------ T3 ----- Pane4 ---------------------------------------------------------------------
public void madd(){
    String h=(T3.getText());
    if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
        equal();
    d1=Double.parseDouble(T3.getText());
    c1='+';T3.setText(T3.getText() + "+");
}
    public void msub(){
        String h=(T3.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T3.getText());
        c1='-';T3.setText(T3.getText() + "-");
    }
    public void mmul(){
        String h=(T3.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T3.getText());
        c1='*';T3.setText(T3.getText() + "*");
    }
    public void mdiv(){
        String h=(T3.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T3.getText());
        c1='/';T3.setText(T3.getText() + "/");
    }
    public void mdel() {
        try {
            String s = T3.getText();
            T3.setText(s.substring(0, s.length() - 1));
        }catch(Exception e){
        }
    }
    public void mclean(){
        T3.setText("");q2.setText("");
    }
    public void mequal(){
        String s1=T3.getText(),s2;
        double d3;
        switch(c1)
        {
            case '+':
                s2=s1.substring(s1.indexOf('+')+1);
                d2=Double.parseDouble(s2);
                d3=d1+d2;
                q2.setText(T3.getText()+"=");
                T3.setText(""+d3);
                break;
            case '-':
                s2=s1.substring(s1.indexOf('-')+1);
                d2=Double.parseDouble(s2);
                d3=d1-d2;
                q2.setText(T3.getText()+"=");
                T3.setText(""+d3);
                break;
            case '*':
                s2=s1.substring(s1.indexOf('*')+1);
                d2=Double.parseDouble(s2);
                d3=d1*d2;
                q2.setText(T3.getText()+"=");
                T3.setText(""+d3);
                break;
            case '/':
                s2=s1.substring(s1.indexOf('/')+1);
                d2=Double.parseDouble(s2);
                d3=d1/d2;
                q2.setText(T3.getText()+"=");
                T3.setText(""+d3);
                break;
            case 'X':
                double my = Double.parseDouble(T3.getText());
                double res = Math.pow(mx,my);
                T3.setText(""+res);
                q2.setText(q2.getText()+my+" =");
                c1 = 'v';
                break;
        }
    }
//-------------------------------------------------------------------------------------------------------------------------

    @FXML
    TextField M1;
    public Label M2;
    @FXML
    Pane Pane1,Pane2,Pane3,Pane4,Pane5,Pane7;
    public void change(){
        Pane2.setVisible(true);
        Pane1.setVisible(false);
    }
    public void back(){
        Pane2.setVisible(false);
        Pane1.setVisible(true);

    }
    //----------------------------------------------------------------------------------------------------------------------
//----------------------- Setting things for length win ----------------------------------------------------------------
    public ComboBox<String> cmb1,cmb2;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        cmb1.setItems(FXCollections.observableArrayList("Metres", "Centimetres", "Feet","Kilometres","Millimetres","Miles"));
        cmb2.setItems(FXCollections.observableArrayList("Metres", "Centimetres", "Feet","Kilometres","Millimetres","Miles"));
    }

    public void lengthWin(){
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Metres", "Centimetres", "Feet","Kilometres","Millimetres","Miles"));
        cmb2.setItems(FXCollections.observableArrayList("Metres", "Centimetres", "Feet","Kilometres","Millimetres","Miles"));
        checkstr = "Length";
        M1.setText("");
        M2.setText("");
    }
    public void fun(ActionEvent e){
        M1.setText((M1.getText())+((Button)e.getSource()).getText());
    }
    public void back1(){
        Pane2.setVisible(true);
        Pane1.setVisible(false);
        Pane3.setVisible(false);}

    public void del1() {
        String s = M1.getText();
        M1.setText(s.substring(0, s.length() - 1));}
    public void lenClear(){
        M1.setText("");M2.setText("");
    }
    //----------------------------- Code for length conversion fns ---------------------------------------------------------
    public double lengthFn(String in,String out,double v){
        switch(in){
            case "Metres":
                switch (out) {
                    case "Millimetres":
                        return v * 1000;
                    case "Centimetres":
                        return v * 100;
                    case "Miles":
                        return v * 0.000621;
                    case "Kilometres":
                        return v * 0.001;
                    case "Feet":
                        return v * 3.28084;
                    case "Metres":
                        return v;

                }

            case "Millimetres":
                switch (out) {
                    case "Metres":
                        return v * 0.001;
                    case "Centimetres":
                        return v * 0.1;
                    case "Miles":
                        return v * 0.000000621371192;
                    case "Kilometres":
                        return v * 0.000001;
                    case "Feet":
                        return v * 0.003281;
                    case "Millimetres":
                        return v;
                }

            case "Centimetres":
                switch (out) {
                    case "Metres":
                        return v * 0.01;
                    case "Millimetres":
                        return v * 10;
                    case "Miles":
                        return v * 0.000006;
                    case "Kilometres":
                        return v * 0.00001;
                    case "Feet":
                        return v * 0.032808;
                    case "Centimetres":
                        return v;
                }

            case "Miles":
                switch (out) {
                    case "Metres":
                        return v * 1609.344;
                    case "Millimetres":
                        return v * 1609344;
                    case "Centimetres":
                        return v * 160934.4;
                    case "Kilometres":
                        return v * 1.609344;
                    case "Feet":
                        return v * 5280;
                    case "Miles":
                        return v;
                }

            case "Kilometres":
                switch (out) {
                    case "Metres":
                        return v * 1000;
                    case "Millimetres":
                        return v * 1000000;
                    case "Centimetres":
                        return v * 100000;
                    case "Miles":
                        return v * 0.621371;
                    case "Feet":
                        return v * 3280.84;
                    case "Kilometres":
                        return v;
                }
            case "Feet":
                switch (out) {
                    case "Metres":
                        return v * 0.3048;
                    case "Millimetres":
                        return v * 304.8;
                    case "Centimetres":
                        return v * 30.48;
                    case "Miles":
                        return v * 0.000189;
                    case "Kilometres":
                        return v * 0.000305;
                    case "Feet":
                        return v;
                }
        }
        return 1;
    }
    // ------------------------------ Setting up for weight conversion -----------------------------------------------------
    public void weightWin() {
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Grams","Kilograms","Milligrams","Tonne","Pounds","Ounces"));
        cmb2.setItems(FXCollections.observableArrayList("Grams","Kilograms","Milligrams","Tonne","Pounds","Ounces"));
        checkstr = "Weight";
        M1.setText("");
        M2.setText("");
    }
    //--------------------- Weight conversion code -------------------------------------------------------------------------
    public double weightFn(String in,String out,double v) {
        switch (in) {
            case "Grams":
                switch (out) {
                    case "Kilograms":
                        return v * 0.001;
                    case "Milligrams":
                        return v * 1000;
                    case "Pounds":
                        return v * 0.002205;
                    case "Ounces":
                        return v * 0.035274;
                    case "Tonne":
                        return v * 0.000001;
                    case "Grams":
                        return v;
                }

            case "Kilograms":
                switch (out) {
                    case "Grams":
                        return v * 1000;
                    case "Pounds":
                        return v * 2.204623;
                    case "Milligrams":
                        return v * 1000000;
                    case "Ounces":
                        return v * 35.27396;
                    case "Tonne":
                        return v * 0.001;
                    case "Kilograms":
                        return v;
                }

            case "Pounds":
                switch (out) {
                    case "Grams":
                        return v * 453.5924;
                    case "Kilograms":
                        return v * 0.453592;
                    case "Milligrams":
                        return v * 453592.4;
                    case "Ounces":
                        return v * 16;
                    case "Tonne":
                        return v * 0.000454;
                    case "Pounds":
                        return v;
                }

            case "Milligrams":
                switch (out) {
                    case "Grams":
                        return v * 0.001;
                    case "Kilograms":
                        return v * 0.000001;
                    case "Pounds":
                        return v * 0.000002;
                    case "Ounces":
                        return v * 0.000035;
                    case "Tonne":
                        return v * 0.000000001;
                    case "Milligrams":
                        return v;
                }

            case "Ounces":
                switch (out) {
                    case "Grams":
                        return v * 28.34952;
                    case "Kilograms":
                        return v * 0.02835;
                    case "Milligrams":
                        return v * 28349.52;
                    case "Pounds":
                        return v * 0.0625;
                    case "Tonne":
                        return v * 0.000028;
                    case "Ounces":
                        return v;
                }
            case "Tonne":
                switch (out) {
                    case "Grams":
                        return v * 1000000;
                    case "Kilograms":
                        return v * 1000;
                    case "Milligrams":
                        return v * 1000000000;
                    case "Pounds":
                        return v * 2204.623;
                    case "Ounces":
                        return v * 35273.96;
                    case "Tonne":
                        return v;

                }
        }
        return 1;
    }
    //---------------------------------- Temp settings ---------------------------------------------------------------------
    public void tempWin(){
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Celsius", "Fahrenheit", "Kelvin"));
        cmb2.setItems(FXCollections.observableArrayList("Celsius", "Fahrenheit", "Kelvin"));
        checkstr = "Temp";
        M1.setText("");
        M2.setText("");
    }
    //----------------------------- Temp conversion code--------------------------------------------------------------------
    public double tempFn(String in,String out,double v) {
        switch (in) {
            case "Celsius":
                switch (out) {
                    case "Fahrenheit":
                        return v * 1.8 + 32;
                    case "Kelvin":
                        return v + 273.15;
                    case "Celsius":
                        return v;
                }
            case "Fahrenheit":
                switch (out) {
                    case "Celsius":
                        return ((v - 32) * 5) / 9;
                    case "Kelvin":
                        return ((v - 32) * 5) / 9 + 273.15;
                    case "Fahrenheit":
                        return v;
                }
            case "Kelvin":
                switch (out) {
                    case "Fahrenheit":
                        return (v - 273.15) * 1.8 + 32;
                    case "Celsius":
                        return v - 273.15;
                    case "Kelvin":
                        return v;
                }
        }
        return 1;
    }
    //-------------------------- Setting up for volume ---------------------------------------------------------------------
    public void volumeWin() {
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Litres","Millilitres","Cubic metres","Gallons","Cubic centimetres","Quarts"));
        cmb2.setItems(FXCollections.observableArrayList("Litres","Millilitres","Cubic metres","Gallons","Cubic centimetres","Quarts"));
        checkstr = "Volume";
        M1.setText("");
        M2.setText("");
    }
    //-------------------------- Vol conversion code -----------------------------------------------------------------------
    public double volumeFn(String in,String out,double v) {
        switch (in) {
            case "Litres":
                switch (out) {
                    case "Millilitres":
                        return v * 1000;
                    case "Cubic metres":
                        return v * 100;
                    case "Gallons":
                        return v * 0.000621;
                    case "Cubic centimetres":
                        return v * 0.001;
                    case "Quarts":
                        return v * 3.28084;
                    case "Litres":
                        return v;
                }

            case "Millilitres":
                switch (out) {
                    case "Litres":
                        return v * 0.001;
                    case "Cubic metres":
                        return v * 0.1;
                    case "Gallons":
                        return v * 0.000000621371192;
                    case "Cubic centimetres":
                        return v * 0.000001;
                    case "Quarts":
                        return v * 0.003281;
                    case "Millilitres":
                        return v;
                }

            case "Cubic metres":
                switch (out) {
                    case "Litres":
                        return v * 0.01;
                    case "Millilitres":
                        return v * 10;
                    case "Gallons":
                        return v * 0.000006;
                    case "Cubic centimetres":
                        return v * 0.00001;
                    case "Quarts":
                        return v * 0.032808;
                    case "Cubic metres":
                        return v;
                }

            case "Gallons":
                switch (out) {
                    case "Litres":
                        return v * 1609.344;
                    case "Millilitres":
                        return v * 1609344;
                    case "Cubic metres":
                        return v * 160934.4;
                    case "Cubic centimetres":
                        return v * 1.609344;
                    case "Quarts":
                        return v * 5280;
                    case "Gallons":
                        return v;
                }

            case "Cubic centimetres":
                switch (out) {
                    case "Litres":
                        return v * 1000;
                    case "Millilitres":
                        return v * 1000000;
                    case "Cubic metres":
                        return v * 100000;
                    case "Gallons":
                        return v * 0.621371;
                    case "Quarts":
                        return v * 3280.84;
                    case "Cubic centimetres":
                        return v;
                }
            case "Quarts":
                switch (out) {
                    case "Litres":
                        return v * 0.3048;
                    case "Millilitres":
                        return v * 304.8;
                    case "Cubic metres":
                        return v * 30.48;
                    case "Gallons":
                        return v * 0.000189;
                    case "Cubic centimetres":
                        return v * 0.000305;
                    case "Quarts":
                        return v;
                }
        }
        return 1;
    }
    //------------------------- Setting up for currency --------------------------------------------------------------------
    public void currencyWin() {
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Dollar","Euro","Rupee","Pound","Dirham"));
        cmb2.setItems(FXCollections.observableArrayList("Dollar","Euro","Rupee","Pound","Dirham"));
        checkstr = "Currency";
        M1.setText("");
        M2.setText("");

    }
    //------------------------- Currency conversion code -------------------------------------------------------------------
    public double currencyFn(String in,String out,double v) {
        switch (in) {
            case "Dollar":
                switch (out) {
                    case "Euro":
                        return v * 0.92;
                    case "Rupee":
                        return v * 83.17;
                    case "Pound":
                        return v * 0.81;
                    case "Dirham":
                        return v * 3.67;
                    case "Dollar":
                        return v;
                }
            case "Euro":
                switch (out) {
                    case "Dollar":
                        return v * 1.08;
                    case "Rupee":
                        return v * 90.24;
                    case "Pound":
                        return v * 0.87;
                    case "Dirham":
                        return v * 3.98;
                    case "Euro":
                        return v;
                }
            case "Rupee":
                switch (out) {
                    case "Dollar":
                        return v * 0.012;
                    case "Euro":
                        return v * 0.011;
                    case "Pound":
                        return v * 0.0097;
                    case "Dirham":
                        return v * 0.044;
                    case "Rupee":
                        return v;
                }
            case "Pound":
                switch (out) {
                    case "Dollar":
                        return v * 1.24;
                    case "Euro":
                        return v * 1.14;
                    case "Rupee":
                        return v * 103.28;
                    case "Dirham":
                        return v * 4.56;
                    case "Pound":
                        return v;
                }
            case "Dirham":
                switch (out) {
                    case "Dollar":
                        return v * 0.27;
                    case "Euro":
                        return v * 0.25;
                    case "Rupee":
                        return v * 22.64;
                    case "Pound":
                        return v * 0.22;
                    case "Dirham":
                        return v;
                }
        }
        return 1;
    }
    //----------------------------------- MathsFun -----------------------------------------------

    @FXML
    public void sWin(ActionEvent event) {
        try {
            ((Stage)(((Button)event.getSource()).getScene().getWindow())).setWidth(870);
            ((Stage)(((Button)event.getSource()).getScene().getWindow())).setHeight(615);
            Pane4.setVisible(true);
            Pane3.setVisible(false);
            Pane2.setVisible(false);
            Pane1.setVisible(false);
        } catch (Exception e) {
            System.out.println("Cant load");
        }
    }
    //-------------------------------------- Setting up for Num Sys ----------------------------------------------------
    public void numWin() {
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Decimal","Binary","Octal","HexaDecimal"));
        cmb2.setItems(FXCollections.observableArrayList("Decimal","Binary","Octal","HexaDecimal"));
        checkstr = "NumSys";
        M1.setText("");
        M2.setText("");
    }
    //------------------------- NumSys conversion code -----------------------------------------------------------------

    public static String numbersystem(String in, String out, String v) {
        switch (in) {
            case "Decimal":
                switch (out) {
                    case "Binary": {
                        int num = Integer.parseInt(v, 10);
                        String binary = Integer.toBinaryString(num);
                        return binary;
                    }
                    case "Octal": {
                        int num = Integer.parseInt(v, 10);
                        String octal = Integer.toOctalString(num);
                        return octal;
                    }
                    case "HexaDecimal":
                    {
                        int num = Integer.parseInt(v, 10);
                        String hexadecimal = Integer.toHexString(num);
                        return hexadecimal;
                    }
                    case "Decimal":
                        return v;
                }
            case "Octal": {
                switch (out) {
                    case "Binary": {
                        int num = Integer.parseInt(v, 8);
                        String binary = Integer.toBinaryString(num);
                        return binary;
                    }
                    case "Decimal": {

                        int num = Integer.parseInt(v, 8);
                        String decimal = Integer.toString(num);
                        return decimal;
                    }
                    case "HexaDecimal": {
                        int num = Integer.parseInt(v, 8);
                        String hexadecimal = Integer.toHexString(num);
                        return hexadecimal;
                    }
                    case "Octal":
                        return v;
                }
            }
            case "Binary": {
                switch (out) {
                    case "Octal": {
                        int num = Integer.parseInt(v, 2);
                        String octal = Integer.toOctalString(num);
                        return octal;
                    }
                    case "Decimal": {
                        int num = Integer.parseInt(v, 2);
                        String decimal = Integer.toString(num);
                        return decimal;
                    }
                    case "HexaDecimal": {
                        int num = Integer.parseInt(v, 2);
                        String hexadecimal = Integer.toHexString(num);
                        return hexadecimal;
                    }
                    case "Binary":
                        return v;
                }
            }
            case "HexaDecimal": {
                switch (out) {
                    case "Binary": {
                        int num = Integer.parseInt(v, 16);
                        String binary = Integer.toBinaryString(num);
                        return binary;
                    }
                    case "Octal": {
                        int num = Integer.parseInt(v, 16);
                        String octal = Integer.toOctalString(num);
                        return octal;
                    }
                    case "Decimal": {
                        System.out.println("hi");
                        int num = Integer.parseInt(v, 16);
                        String decimal = Integer.toString(num);
                        return decimal;
                    }
                    case "HexaDecimal":
                        return v;

                }
            }
        }
        return "Nothing";
    }

    //------------------- Settings for Stats---------------------------------------------------
    public void statsWin() {
        Pane5.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        checkstr = "Stats";
    }
    public void backS()
    {
        Pane5.setVisible(false);
        Pane2.setVisible(true);

    }
    //---------------------Setting function for Statics--------------
    @FXML
    TextArea Tx1,Tx3;
    @FXML
    TextField Tx2,Tx4;
    int number,fs=-1;
    int num[];
    @FXML
    public void funs(ActionEvent ev){
        Tx2.setText((Tx2.getText())+((Button)ev.getSource()).getText());
    }
    public void dels() {
        String s = Tx2.getText();
        Tx2.setText(s.substring(0, s.length() - 1));}
    public void lenClearS(){
        Tx2.setText("");
        Tx3.setText("");
        Tx4.setText("");
        fs=-1;
        Tx1.setText("Enter the number \nof data points.");
    }

    public void calstat()
    {

        int zx=Tx1.getText().indexOf("E");
    if(zx==0)
    {
        number = Integer.parseInt(Tx2.getText());
        num = new int[number];
        Tx1.setText("Please enter "+number+"\nnumber one by one");
        Tx2.setText("");
    }
    else if(Tx2.getText()!="")
    {
         fs++;
         num[fs]=Integer.parseInt(Tx2.getText());
         if(fs==(number-1))
         {
             Tx2.setText("Done");
             Tx1.setText("Please choose the required\noperation");

         }
         else
            Tx2.setText("");

    }
    }
    public static double Statistics(String in, int v[]) {
        int n = v.length;
        switch (in) {
            case "Mean": {
                int sum = 0;
                for (int i = 0; i < n; i++) {
                    sum += v[i];
                }
                return sum / (float) n;
            }
            case "Median": {
                Arrays.sort(v);
                int middle = v.length / 2;
                if (v.length % 2 == 1) {
                    return v[middle];
                } else {
                    return (v[middle - 1] + v[middle]) / 2.0;
                }
            }
            case "Mode": {
                int maxValue = 0;
                int maxCount = 0;

                for (int i = 0; i < v.length; ++i) {
                    int count = 0;
                    for (int j = 0; j < v.length; ++j) {
                        if (v[j] == v[i]) ++count;
                    }
                    if (count > maxCount) {
                        maxCount = count;
                        maxValue = v[i];
                    }
                }

                return maxValue;
            }
            case "Std.Dev.": {
                double sum = 0.0;
                double standardDeviation = 0.0;
                double mean = 0.0;
                double res = 0.0;
                double sq = 0.0;

                for (int i = 0; i < n; i++) {
                    sum = sum + v[i];
                }

                mean = sum / (n);

                for (int i = 0; i < n; i++) {

                    standardDeviation
                            = standardDeviation + Math.pow((v[i] - mean), 2);

                }

                sq = standardDeviation / n;
                res = Math.sqrt(sq);
                return res;
            }
            case "Variance": {
                double sum = 0.0;
                double Diffsquare = 0.0;
                double mean = 0.0;
                double res = 0.0;
                double sq = 0.0;

                for (int i = 0; i < n; i++) {
                    sum = sum + v[i];
                }

                mean = sum / (n);

                for (int i = 0; i < n; i++) {

                    Diffsquare
                            = Diffsquare + Math.pow((v[i] - mean), 2);

                }

                return Diffsquare / n;
            }
        }
        return 0;
    }


    public void RUN(ActionEvent e)
    {

        String bname=((Button)e.getSource()).getText();
       double stat=Statistics(bname,num);
       Tx3.setText(bname);
       Tx4.setText(""+stat);
    }

    //--------------------- Settings for graph ---------------------------------------------------
    public void graphWin() {
        Pane7.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        checkstr = "Graph";
    }

    //------------------------------------ General equal button code -------------------------------------------------------
    public void leq(){
        double Y2,y1;
        String s1;
        switch (checkstr){
            case "Length":
                y1=Double.parseDouble(M1.getText());
                Y2=lengthFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "Weight":
                y1=Double.parseDouble(M1.getText());
                Y2=weightFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "Temp":
                y1=Double.parseDouble(M1.getText());
                Y2=tempFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "Volume":
                y1=Double.parseDouble(M1.getText());
                Y2=volumeFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "Currency":
                y1=Double.parseDouble(M1.getText());
                Y2=currencyFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "NumSys":
//                String mt = M1.getText();
                s1=numbersystem(cmb1.getValue(),cmb2.getValue(),M1.getText());
                M2.setText(""+s1);
                break;
        }
    }
}

